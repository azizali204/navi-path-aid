package com.az.lumivoice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatTurn(val role: String, val content: String)

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("lumi_prefs", Context.MODE_PRIVATE)
    private val secure = SecureStore(context)

    var baseUrl: String
        get() = prefs.getString("base_url", DEFAULT_URL) ?: DEFAULT_URL
        set(value) = prefs.edit().putString("base_url", value.trim()).apply()

    var apiKey: String
        get() = secure.getSecret("api_key") ?: ""
        set(value) = secure.saveSecret("api_key", value.trim())

    var speakReplies: Boolean
        get() = prefs.getBoolean("speak_replies", true)
        set(value) = prefs.edit().putBoolean("speak_replies", value).apply()

    val sessionId: String
        get() = getOrCreate("session_id", "lumi-voice-")

    val sessionKey: String
        get() = getOrCreate("session_key", "agent:main:lumi-voice:")

    private fun getOrCreate(name: String, prefix: String): String {
        var value = prefs.getString(name, null)
        if (value.isNullOrBlank()) {
            value = prefix + UUID.randomUUID().toString()
            prefs.edit().putString(name, value).apply()
        }
        return value
    }

    fun readHistory(): MutableList<ChatTurn> {
        val raw = prefs.getString("history", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                ChatTurn(o.optString("role"), o.optString("content"))
            }
        } catch (_: Throwable) { mutableListOf() }
    }

    fun appendTurn(role: String, content: String, maxTurns: Int = 6) {
        val history = readHistory()
        history.add(ChatTurn(role, content))
        while (history.size > maxTurns) history.removeAt(0)
        val arr = JSONArray()
        history.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    companion object {
        const val DEFAULT_URL = "https://hermes-agent-xqfd.srv1974597.hstgr.cloud/lumi-api"
    }
}
