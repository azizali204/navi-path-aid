package com.az.lumivoice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class VoiceInput(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    fun start(onStatus:(String)->Unit, onResult:(String)->Unit, onError:(String)->Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { onError("التعرف على الصوت غير متوفر"); return }
        destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { sr ->
            sr.setRecognitionListener(object: RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = onStatus("أسمعك الآن…")
                override fun onBeginningOfSpeech() = onStatus("تحدث…")
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() = onStatus("جاري الإرسال…")
                override fun onError(error: Int) = onError("خطأ صوتي ($error)")
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                    if (t.isBlank()) onError("لم ألتقط كلامًا") else onResult(t)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            sr.startListening(i)
        }
    }
    fun destroy() { recognizer?.cancel(); recognizer?.destroy(); recognizer = null }
}
