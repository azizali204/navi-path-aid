package com.az.lumivoice

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class HermesClient(private val prefs: AppPrefs) {
    data class Result(val answer: String, val httpCode: Int)

    private fun endpoint(): String {
        val base = prefs.baseUrl.trim().trimEnd('/')
        require(base.startsWith("https://")) { "استخدم رابط HTTPS" }
        return if (base.endsWith("/v1/chat/completions")) base else "$base/v1/chat/completions"
    }

    fun probe(): Int {
        require(prefs.apiKey.isNotBlank()) { "أدخل API Server Key" }
        val c = (URL(endpoint()).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${prefs.apiKey}")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject().put("model", "hermes-agent")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "قل فقط: اتصال ناجح")))
            .put("stream", false)
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        c.inputStream?.close()
        c.disconnect()
        return code
    }

    fun send(text: String): Result {
        require(text.isNotBlank()) { "الأمر فارغ" }
        require(prefs.apiKey.isNotBlank()) { "أدخل API Server Key" }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", "أنت لومي. أجب بالعربية باختصار وبالنتيجة النهائية فقط."))
        prefs.readHistory().forEach { messages.put(JSONObject().put("role", it.role).put("content", it.content)) }
        messages.put(JSONObject().put("role", "user").put("content", text))
        val body = JSONObject().put("model", "hermes-agent").put("messages", messages).put("stream", false)
        val c = (URL(endpoint()).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 180000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${prefs.apiKey}")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Hermes-Session-Id", prefs.sessionId)
            setRequestProperty("X-Hermes-Session-Key", prefs.sessionKey)
        }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Hermes HTTP $code: ${raw.take(300)}")
        val answer = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.trim().orEmpty()
        require(answer.isNotBlank()) { "لم يصل رد نهائي" }
        prefs.appendTurn("user", text); prefs.appendTurn("assistant", answer)
        return Result(answer, code)
    }
}
