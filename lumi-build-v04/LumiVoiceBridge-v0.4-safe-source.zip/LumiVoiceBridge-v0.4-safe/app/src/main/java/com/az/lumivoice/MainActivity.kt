package com.az.lumivoice

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import kotlinx.coroutines.*

class MainActivity : Activity() {
    private lateinit var prefs: AppPrefs
    private lateinit var client: HermesClient
    private lateinit var base: EditText
    private lateinit var key: EditText
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private var voice: VoiceInput? = null
    private var speaker: TtsSpeaker? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = AppPrefs(applicationContext)
        client = HermesClient(prefs)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun text(t:String, size:Float=16f): TextView = TextView(this).apply { text=t; textSize=size; setPadding(0,dp(6),0,dp(6)) }
        fun button(t:String, action:()->Unit): Button = Button(this).apply { text=t; setOnClickListener{action()} }

        root.addView(text("لومي — وضع التشغيل الآمن", 24f))
        status = text("الحالة: الواجهة تعمل", 16f); root.addView(status)

        root.addView(text("رابط Hermes API"))
        base = EditText(this).apply {
            setText(runCatching { prefs.baseUrl }.getOrDefault(AppPrefs.DEFAULT_URL))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_LTR
        }
        root.addView(base, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(text("API Server Key"))
        key = EditText(this).apply {
            setText(runCatching { prefs.apiKey }.getOrDefault(""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_LTR
        }
        root.addView(key, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(button("حفظ الإعدادات") { save() })
        root.addView(button("اختبار الاتصال") { if (save()) test() })
        root.addView(button("🎙 اضغط وتحدث") { talk() })
        answer = text("—", 17f); root.addView(answer)
        root.addView(text("هذه نسخة تشغيل آمن لعزل سبب الإغلاق. الاستماع الدائم سيُعاد بعد ثبات التشغيل.", 13f))
        return scroll
    }

    private fun save(): Boolean {
        val u = base.text.toString().trim(); val k = key.text.toString().trim()
        if (!u.startsWith("https://")) { toast("الرابط يجب أن يبدأ بـ https://"); return false }
        if (k.isBlank()) { toast("أدخل API Server Key"); return false }
        return runCatching { prefs.baseUrl=u; prefs.apiKey=k; true }.getOrElse { toast("تعذر الحفظ: ${it.message}"); false }
    }

    private fun test() {
        status.text = "الحالة: أختبر الاتصال…"
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { client.probe() } }
            status.text = if (r.isSuccess && r.getOrNull() in 200..299) "الحالة: الاتصال ناجح ✓" else "الحالة: فشل الاتصال"
            if (r.isFailure) toast(r.exceptionOrNull()?.message ?: "خطأ")
        }
    }

    private fun talk() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (!save()) return
        val v = voice ?: VoiceInput(applicationContext).also { voice = it }
        v.start(
            onStatus = { runOnUiThread { status.text = "الحالة: $it" } },
            onResult = { send(it) },
            onError = { runOnUiThread { status.text = "الحالة: $it" } }
        )
    }

    private fun send(text:String) {
        status.text = "الحالة: لومي تعمل…"
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { client.send(text) } }
            r.onSuccess {
                answer.text = it.answer
                status.text = "الحالة: جاهزة"
                val s = speaker ?: runCatching { TtsSpeaker(applicationContext) }.getOrNull()?.also { speaker = it }
                s?.speak(it.answer)
            }.onFailure { status.text = "الحالة: خطأ"; toast(it.message ?: "خطأ") }
        }
    }

    private fun toast(s:String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { voice?.destroy(); speaker?.shutdown(); scope.cancel(); super.onDestroy() }
}
